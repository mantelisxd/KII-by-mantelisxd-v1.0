Prieš pradedant:

1. Spausk ant paleidiklis.bat
2. Atsiras UAC langas - spausk Yes/Taip
3. Ekrane pasirodys mažas langas, kuriame viršuj pasirinksi veiksmą, žemiau laiką.
4. JEI LAIKĄ RAŠAI HH:MM tau veiksmas bus įvykdytas pagal laikrodį 
pvz.: įrašai 01:00 tai reikš, jog veiksmas bus įvykdytas 1 valandą nakties, o ne po vienos valandos.
Visais kitais atvejais laikas skaičiuosis nuo tada kiek parašyta 
pvz.: 01:00:00 arba 3600 - veiksmas bus atliktas po valandos (galioja HH:MM:SS ir sek formatams.)
5. Atėjus laikui programa užsidarys ir kompiuteris padarys tai ką buvai pasirinkęs.

Thank you for watching and fuck off (chems_)