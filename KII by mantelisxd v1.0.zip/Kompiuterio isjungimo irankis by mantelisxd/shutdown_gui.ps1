# --- ADMIN CHECK (NO NEW POWERSHELL WINDOW) -------------------------
$IsAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltInRole] "Administrator"
)

if (-not $IsAdmin) {
    # Relaunch silently with admin (NO powershell window)
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = "powershell.exe"
    $psi.Arguments = "-ExecutionPolicy Bypass -WindowStyle Hidden -File `"$PSCommandPath`""
    $psi.Verb = "runas"
    $psi.WindowStyle = "Hidden"
    [System.Diagnostics.Process]::Start($psi) | Out-Null
    exit
}

# --- GUI START -------------------------------------------------------
Add-Type -AssemblyName PresentationFramework

[xml]$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        Title="Kompiuterio isjungimo irankis by mantelisxd" Height="300" Width="400" ResizeMode="NoResize">
  <StackPanel Margin="10">
    <TextBlock Text="Pasirinkite veiksma:" FontSize="14" Margin="0,0,0,5"/>
    <ComboBox Name="ActionBox">
      <ComboBoxItem Content="Atsijungti (Log Out)" />
      <ComboBoxItem Content="Isjungti (Shut Down)" />
      <ComboBoxItem Content="Perkrauti (Restart)" />
      <ComboBoxItem Content="Paleisti i Safe Mode" />
      <ComboBoxItem Content="Grizti i Normal Mode" />
    </ComboBox>
    <TextBlock Text="Laikas iki veiksmo (sek arba HH:MM:SS arba HH:MM):" Margin="0,10,0,5"/>
    <TextBox Name="DelayBox" Text="10"/>
    <TextBlock Name="CountdownText" Text="" FontSize="16" Margin="0,10,0,5" HorizontalAlignment="Center"/>
    <ProgressBar Name="ProgressBar" Height="20" Minimum="0" Maximum="100" Margin="0,5,0,5"/>
    <StackPanel Orientation="Horizontal" HorizontalAlignment="Center" Margin="0,10,0,0">
      <Button Name="GoBtn" Content="Vykdyti" Width="80" Margin="5"/>
      <Button Name="CancelBtn" Content="Atsaukti" Width="80" Margin="5"/>
    </StackPanel>
  </StackPanel>
</Window>
"@

$reader = (New-Object System.Xml.XmlNodeReader $xaml)
$window = [Windows.Markup.XamlReader]::Load($reader)
$actionBox   = $window.FindName("ActionBox")
$delayBox    = $window.FindName("DelayBox")
$goBtn       = $window.FindName("GoBtn")
$cancelBtn   = $window.FindName("CancelBtn")
$countdownText = $window.FindName("CountdownText")
$progressBar = $window.FindName("ProgressBar")

$timer = New-Object System.Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromSeconds(1)
$global:remaining = 0
$global:total = 0
$cancelled = $false

$timer.Add_Tick({
    if ($global:remaining -le 0) {
        $timer.Stop()
        $countdownText.Text = "00:00:00"
        Start-Sleep -Seconds 1
        if (-not $cancelled) {
            switch ($actionBox.SelectedIndex) {
                0 { shutdown /l /f }
                1 { shutdown /s /f /t 0 }
                2 { shutdown /r /f /t 0 }
                3 { bcdedit /set {current} safeboot minimal; Start-Sleep -Seconds 2; shutdown /r /f /t 0 }
                4 { bcdedit /deletevalue {current} safeboot; Start-Sleep -Seconds 2; shutdown /r /f /t 0 }
            }
        }
        $window.Close()
    } else {
        $global:remaining--
        $span = [TimeSpan]::FromSeconds($global:remaining)
        $countdownText.Text = $span.ToString("hh\:mm\:ss")
        if ($global:total -gt 0) {
            $progressBar.Value = 100 * ($global:total - $global:remaining) / $global:total
        }
    }
})

$goBtn.Add_Click({
    $input = $delayBox.Text.Trim()
    $global:total = 0

    if ($input -match '^[0-9]+$') {
        $global:total = [int]$input
    }
    elseif ($input -match '^(\d{1,2}):(\d{1,2}):(\d{1,2})$') {
        $h = [int]$matches[1]; $m = [int]$matches[2]; $s = [int]$matches[3]
        $global:total = ($h * 3600) + ($m * 60) + $s
    }
    elseif ($input -match '^(\d{1,2}):(\d{1,2})$') {
        $target = (Get-Date).Date.AddHours([int]$matches[1]).AddMinutes([int]$matches[2])
        $now = Get-Date
        if ($target -lt $now) { $target = $target.AddDays(1) }
        $global:total = [int]($target - $now).TotalSeconds
    } else {
        [System.Windows.MessageBox]::Show("Netinkamas laiko formatas.", "Klaida")
        return
    }

    if ($global:total -le 0) {
        [System.Windows.MessageBox]::Show("Iveskite laika didesni nei 0.", "Klaida")
        return
    }

    $cancelled = $false
    $global:remaining = $global:total
    $progressBar.Value = 0
    $span = [TimeSpan]::FromSeconds($global:remaining)
    $countdownText.Text = $span.ToString("hh\:mm\:ss")
    $timer.Start()
})

$cancelBtn.Add_Click({
    $timer.Stop()
    $cancelled = $true
    $countdownText.Text = "Operacija atsaukta"
})

$window.ShowDialog() | Out-Null
